package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Tareas;

/**
 * Servlet implementation class Alta_Tarea
 */
@WebServlet("/Alta_Tarea")
public class Alta_Tarea extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Alta_Tarea() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

		/*try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		String titulo = request.getParameter("titulo");
		String descripcion = request.getParameter("descripcion");
		int categoria = Integer.parseInt(request.getParameter("categoria"));
		int importancia = Integer.parseInt(request.getParameter("importancia"));
		int dependencia = Integer.parseInt(request.getParameter("dependencia"));
		//int estado = Integer.parseInt(request.getParameter("estado"));
		
		/*
		Date fecha_inicio = new Date();
		Date fecha_fin = new Date();
		
		try {
			fecha_inicio = new SimpleDateFormat().parse(request.getParameter("f_incio"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		try {
			fecha_fin= new SimpleDateFormat().parse(request.getParameter("f_final"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		*/
		
Tareas t = new Tareas ();
		
		t.setTitulo(titulo);
		t.setDescripcion(descripcion);
		t.setCategoria(categoria);
		t.setImportancia(importancia);
	//	t.setFecha_inicio(fecha_inicio);
	//	t.setFecha_fin(fecha_fin);
		try {
			t.insertar();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		//response.getWriter().print(t.toString());
		
		
		 
		
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
