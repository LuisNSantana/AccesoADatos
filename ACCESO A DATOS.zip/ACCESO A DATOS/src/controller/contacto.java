package controller;

public class contacto {
	
	String nombre;
	String apellido;
	String email;
	String texttarea;
	
	public String toString() {
		return "Contacto [ nombre=" + nombre + ", apellido=" + apellido + ", email="
				+ email + ", texttarea=" + texttarea+ "]";
	}

	public contacto() {
		
	}
	
	public contacto(String nombre, String apellido, String email, String texttarea) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.email = email;
		this.texttarea = texttarea;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTexttarea() {
		return texttarea;
	}

	public void setTexttarea(String texttarea) {
		this.texttarea = texttarea;
	}
	
}
