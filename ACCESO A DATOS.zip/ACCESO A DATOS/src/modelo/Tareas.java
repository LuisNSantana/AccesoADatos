package modelo;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import dao.DAOTarea;

public class Tareas {
	private int id;
	private String titulo;
	private String descripcion;
	private int importancia;
	private Date fecha_inicio;
	private Date fecha_fin;
	private int categoria;
	private ArrayList<Integer>depende;
	//int estado;
	
	
	@Override
	public String toString() {
		return "Tareas [id=" + id + ", titulo=" + titulo + ", descripcion=" + descripcion + ", importancia="
				+ importancia + ", fecha_inicio=" + fecha_inicio + ", fecha_fin=" + fecha_fin + ", categoria="
				+ categoria + ", depende=" + depende + "]";
	}

	public Tareas() {
		
	}
	
	public Tareas (int id, String titulo,String descripcion ,int importancia, Date fecha_inicio, Date fecha_fin,
		int categoria, ArrayList<Integer> depende /*estado*/	) {
		
		super();
		
		this.id = id;
		this.titulo = titulo;
		this.descripcion = descripcion;
		this.importancia = importancia;
		this.fecha_inicio = fecha_inicio;
		this.fecha_fin = fecha_fin;
		this.categoria = categoria;
		this.depende = depende;
		//this.estado = estado;
		
		 
	}

	/*public int getEstado() {
		return estado;
	}

	public void setEstado(int estado) {
		this.estado = estado;
	}*/

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getImportancia() {
		return importancia;
	}

	public void setImportancia(int importancia) {
		this.importancia = importancia;
	}

	public Date getFecha_inicio() {
		return fecha_inicio;
	}

	public void setFecha_inicio(Date fecha_inicio) {
		this.fecha_inicio = fecha_inicio;
	}

	public Date getFecha_fin() {
		return fecha_fin;
	}

	public void setFecha_fin(Date fecha_fin) {
		this.fecha_fin = fecha_fin;
	}

	public int getCategoria() {
		return categoria;
	}

	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	public ArrayList<Integer> getDepende() {
		return depende;
	}

	public void setDepende(ArrayList<Integer> depende) {
		this.depende = depende;
	}
	
	public void insertar() throws ClassNotFoundException {
		
		
		try {
			DAOTarea.getInstance().insert(this);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

}
