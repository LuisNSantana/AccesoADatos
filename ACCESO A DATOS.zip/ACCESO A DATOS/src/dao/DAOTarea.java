package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import conexion.DBConnection;
import modelo.Tareas;

public class DAOTarea {

	private Connection con = null;

	public static DAOTarea instance = null;

	public DAOTarea() throws SQLException, ClassNotFoundException {
		con = DBConnection.getConnection();
	}

	public static DAOTarea getInstance() throws SQLException, ClassNotFoundException {
		if (instance == null)
			instance = new DAOTarea();
		return instance;
	}
	


	
	
	
	public void insert(Tareas t) throws SQLException {
		PreparedStatement ps = con.prepareStatement("INSERT INTO tareas"
				+ " (titulo, descripcion, categoria, importancia,dependencia,estado  ) VALUES (?,?,?,?,?,?)");
		ps.setString(1, t.getTitulo());
		ps.setString(2, t.getDescripcion());
		ps.setInt(3, t.getCategoria());
		ps.setInt(4, t.getImportancia() );
		//ps.setInt(5, t.getDepende());
		//ps.setInt(6, t.getEstado());
		/*...........*/
		System.out.println(ps.toString());
		System.out.println(ps.toString());
		ps.executeUpdate();
		ps.close();
	}
	
	
	/*public void update(Tareas t) throws SQLException{
		
		PreparedStatement ps = con.prepareStatement("UPDATE tarea SET titulo = ?, descripcion = ? ... WHERE id = ");
		ps.setString(1, t.getTitulo());
		
		ps.executeUpdate();
		ps.close();
		
	}
	public ArrayList<Tareas> listaTareas(){
		
		//creo una lista vacia
		ArrayList<Tareas> lista = null;
		
		
		/*try {
			
			PreparedStatement ps = con.prepareStatement("SELECT * FROM tareas");
			 ResultSet resultado = ps.executeQuery();
			 
				while(resultado.next()) {
					
					
					Tareas t = new Tareas(resultado.getInt("id"), resultado.getString("titulo"), 
							resultado.getString("descripcion"), resultado.getInt("categoria"),
							resultado.getInt("importancia"),
							resultado.getInt("dependencia"),resultado.getInt("estado"));
					
					lista.add(t); 
				}
				
						} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
	
		
		
		//retorno la lista con los datos
		//return lista;
	//}
	
	
	
}



